var express = require('express');
var router = express.Router();
var HttpClient = require("../tools/HttpClient");
var StringUtil = require("../tools/StringUtil");


/* GET home page. */
router.get('/', function(req, res, next) {
    let data = {}
    HttpClient.get(HttpClient.url+"/index").then(function(data){
        data.url = "//m.asbdk.com/static/maoyan/images/film/";
        if(req.session){
        	data.user = req.session.user || {};
        }      
        res.render('index.ejs',data);
        // res.send(data);

    });

});
router.get('/login', function(req, res, next) {
    res.render('login.ejs',{error:0});
    
});
router.post('/reg', function(req, res, next) {
    res.render('register.ejs'); 
    
});




module.exports = router;
