let HttpClient = require("../../tools/HttpClient");
require("should");

suite("HttpClient接口测试",function(){
	suiteSetup(function(){
		console.log("所有测试之前执行的")
	});
	setup(function(){
		console.log("setup...");
	})
	suite("测试get请求",function(){
		test("测试无参的get请求",function(done){
			HttpClient.get("back:8080/maoyan-back/index1").then(function(data){
				data.should.have.ownProperty("orderByBoxOffice","数据不正确");
				done();
			});
		});
		test("测试有参的get请求",function(done){
			HttpClient.get("back:8080/maoyan-back/login",{phone:"18988888888",pwd:"111112"}).then(function(data){
				data.should.Object();
				done();
			});
		});
	});
	suite("测试post请求",function(){
		test("测试有参的post请求",function(done){
			HttpClient.get("back:8080/maoyan-back/reg",{phone:"18988888889",pwd:"111111"}).then(function(data){
				should.equal(data,"ok");
				done();
			});
		});
	});
	
});