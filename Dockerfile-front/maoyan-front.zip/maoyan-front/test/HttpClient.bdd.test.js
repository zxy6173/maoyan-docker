let HttpClient = require("../tools/HttpClient");
require("should");

describe('HttpClient接口',function(){
	describe('HttpClient的get和post方法',function(){
		it('访问get方法应该得到异步对象',function(){
			let asyncObj = HttpClient.get("back:8080/maoyan-back/index");
			asyncObj.should.be.Promise();
		});
		it('访问post方法应该得到异步对象',function(){
			let asyncObj = HttpClient.post("back:8080/maoyan-back/index");
			asyncObj.should.be.Promise();
		});
	});
	describe('get请求',function(){
		it('应该可以实现无参数的get提交',function(done){
			HttpClient.get("back:8080/maoyan-back/index").then(function(data){
				data.should.have.ownProperty("orderByBoxOffice","数据不正确");
				done();
			});
		});
		it('应该可以实现有参数的get提交',function(done){
			HttpClient.get("back:8080/maoyan-back/login",{phone:"18988888888",pwd:"111112"}).then(function(data){
				data.should.Object();
				done();
			});
		});
	})
	describe('post请求',function(){
		it("测试有参的post请求",function(done){
			HttpClient.get("back:8080/maoyan-back/reg",{phone:"18988888889",pwd:"111111"}).then(function(data){
				should.equal(data,"ok");
				done();
			});
		});
	})
})

