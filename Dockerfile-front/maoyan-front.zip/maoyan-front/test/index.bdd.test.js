let request = require("supertest");
let app = require("../app");
require("should");
require("should-http");

describe('index路由',function(){
	it('访问首页',function(done){
		request(app).get("/").then(function(res){
			res.should.be.html();
			should.equal(res.status,200);
			done();
		});
	});
	it('访问登录',function(done){
		request(app).get("/login").then(function(res){
			res.should.be.html();
			should.equal(res.status,200);
			done();
		});
	});
	it('访问注册',function(done){
		request(app).post("/reg").then(function(res){
			res.should.be.html();
			should.equal(res.status,200);
			done();
		});
	});
})