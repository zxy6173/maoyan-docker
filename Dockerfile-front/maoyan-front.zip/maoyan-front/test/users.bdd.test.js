let request = require("supertest");
let app = require("../app");
require("should");
require("should-http");

describe('users路由', function() {
    describe('请求用户名是否已存在', function() {
        it('如果存在应该返回状态0', function(done) {
            request(app).get("/users/findByPhone?phone=18988888880").then(function(res) {
                should.equal(res.body.status, 0);
                done();
            });
        });
        it('如果不存在应该返回状态1', function(done) {
            request(app).get("/users/findByPhone?phone=18988888881").then(function(res) {
                should.equal(res.body.status, 1);
                done();
            });
        });
    });
    describe('登录验证', function() {
        it('如果用户名或密码正确应该跳转首页', function(done) {
            request(app).post("/users/login").send("phone=18988888880&pwd=123123").then(function(res) {
                should.equal(res.status, 302);
                done();
            });
        });
        it('如果用户名或密码不正确应该跳转登录页面', function(done) {
            request(app).post("/users/login").send("phone=18988888880&pwd=111111").then(function(res) {
                res.should.be.html();
                should.equal(res.status, 200);
                done();
            });
        });
    });
    it('用用户名和密码进行注册', function(done) {
        request(app).post("/users/reg").send("phone=18988888880&pwd=123123").then(function(res) {
            should.equal(res.status, 302);
            done();
        });
    });
    it('注销', function(done) {
        request(app).get("/users/logout").then(function(res) {
            should.equal(res.status, 302);
            done();
        });
    });
})