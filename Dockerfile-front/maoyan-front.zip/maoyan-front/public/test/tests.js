describe("注册验证", function() {
	before(function() {
            $(document.body).append("<div id='content' ></div>");
            $("#content").load("http://localhost:3000/reg", function() {
                $.getScript("base/js/register.js", function() {
                    $(window).trigger("load");
                });

            });

     })
    describe("手机号验证", function() {
        
        it("手机号格式不正确", function(done) {
            setTimeout(function() {
                $("input[name=phone]").trigger("focus");
                $("input[name=phone]").val("123123555");
                $("input[name=phone]").trigger("blur");
                should.equal($("input[name=phone]").next().text(), "格式不正确");
                done();

            }, 1000)
        });
        it("手机号重复", function(done) {
            setTimeout(function() {
                $("input[name=phone]").trigger("focus");
                $("input[name=phone]").val("18988888889");
                $("input[name=phone]").trigger("blur");
                setTimeout(function() {

                    should.equal($("input[name=phone]").next().text(), "手机已被注册");

                    done();
                }, 500);

            }, 1000)

        });
        it("手机号可用", function(done) {
            setTimeout(function() {
                $("input[name=phone]").trigger("focus");
                $("input[name=phone]").val("18988888811");
                $("input[name=phone]").trigger("blur");
                setTimeout(function() {

                    should.equal($("input[name=phone]").next().text(), "");

                    done();
                }, 500);

            }, 1000)

        });
    });

    describe("验证码验证", function() {
        
        it("验证码格式不正确", function(done) {
            setTimeout(function() {
                $("input[name=verifycode]").trigger("focus");
                $("input[name=verifycode]").val("aaa");
                $("input[name=verifycode]").trigger("blur");
                should.equal($("input[name=verifycode]").next().text(), "格式不正确");
                done();

            }, 1000)
        });
        it("验证码格式正确", function(done) {
            setTimeout(function() {
                $("input[name=verifycode]").trigger("focus");
                $("input[name=verifycode]").val("123123");
                $("input[name=verifycode]").trigger("blur");
                should.equal($("input[name=verifycode]").next().text(), "");
				done();

            }, 1000)

        });
    });

    describe("密码验证", function() {
        
        it("密码格式不正确", function(done) {
            setTimeout(function() {
                $("input[name=pwd]").trigger("focus");
                $("input[name=pwd]").val("123aa");
                $("input[name=pwd]").trigger("blur");
                should.equal($("input[name=pwd]").next().text(), "格式不正确");
                done();

            }, 1000)
        });
        it("验证码格式正确", function(done) {
            setTimeout(function() {
                $("input[name=pwd]").trigger("focus");
                $("input[name=pwd]").val("12345678");
                $("input[name=pwd]").trigger("blur");
                should.equal($("input[name=pwd]").next().text(), "");
				done();

            }, 1000)

        });
    });
    describe("确认密码验证", function() {
        
        it("两次密码不一致", function(done) {
            setTimeout(function() {
                $("input[name=password2]").trigger("focus");
                $("input[name=password2]").val("123456");
                $("input[name=password2]").trigger("blur");
                should.equal($("input[name=password2]").next().text(), "密码不一致");
                done();

            }, 1000)
        });
        it("两次密码一致", function(done) {
            setTimeout(function() {
                $("input[name=password2]").trigger("focus");
                $("input[name=password2]").val("12345678");
                $("input[name=password2]").trigger("blur");
                should.equal($("input[name=password2]").next().text(), "");
				done();

            }, 1000)

        });
    });
});