var path = require("path");
var webpack = require("webpack");
module.exports = {
    //入口
    entry : [
        path.join(__dirname,"test/index.test.js")

    ],
    //输出
    output : {
        path : path.join(__dirname,"test"),
        filename : "index.test.bundle.js"
    },
    module:{
        rules:[
            {test:/\.js$/,use:['babel-loader'],exclude:/node_modules/}
        ]
    }
    
}
